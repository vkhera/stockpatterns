from cryptography.fernet import Fernet
import getpass
import json

# Generate a key and save it for future use
key = Fernet.generate_key()
fernet = Fernet(key)

username = input("Enter your Robinhood username: ")
password = getpass.getpass("Enter your Robinhood password: ")

# Encrypt the password
enc_password = fernet.encrypt(password.encode()).decode()

# Save to config.json
config = {
    "username": username,
    "password": enc_password,
    "key": key.decode()
}

with open("config.json", "w") as f:
    json.dump(config, f, indent=2)

print("Credentials encrypted and saved to config.json.")

import robin_stocks as r
import pandas as pd
import yfinance as yf
import json
from cryptography.fernet import Fernet
import numpy as np

# Load credentials from config file
with open('config.json', 'r') as f:
    config = json.load(f)

username = config['username']
key = config['key'].encode()
fernet = Fernet(key)
password = fernet.decrypt(config['password'].encode()).decode()

# Login to Robinhood
login = r.robinhood.authentication.login(username, password)

if login['access_token']:
    print("Login successful! Fetching holdings...")
    holdings = r.robinhood.account.build_holdings()
    if holdings:
        print("Current Holdings:")
        data = []
        for symbol, info in holdings.items():
            print(f"{symbol}: {info['quantity']} shares @ ${info['price']} each, Equity: ${info['equity']}")
            # Fetch beta using yfinance
            try:
                ticker = yf.Ticker(symbol)
                beta = ticker.info.get('beta', 'N/A')
            except Exception as e:
                beta = 'N/A'
            data.append({
                'Symbol': symbol,
                'Quantity': info['quantity'],
                'Price': info['price'],
                'Equity': info['equity'],
                'Percent Change': info['percent_change'],
                'Type': info['type'],
                'Beta': beta
            })
        # Export to CSV
        df = pd.DataFrame(data)
        df.to_csv('holdings_report.csv', index=False)
        print("Holdings exported to holdings_report.csv with Beta column.")
    else:
        print("No holdings found.")
else:
    print("Login failed. Please check your credentials.")

# --- Portfolio risk analysis ---
# Read holdings report
df = pd.read_csv('holdings_report.csv')

# Ensure 'Equity' and 'Beta' columns are numeric
for col in ['Equity', 'Beta']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Calculate portfolio weights
total_equity = df['Equity'].sum()
df['Weight'] = df['Equity'] / total_equity

# Calculate portfolio beta
portfolio_beta = (df['Weight'] * df['Beta']).sum()

with open('portfolio_beta.txt', 'w') as f:
    f.write('Portfolio Beta Calculation Details\n')
    f.write('---------------------------------\n')
    f.write(df[['Symbol', 'Equity', 'Weight', 'Beta']].to_string(index=False))
    f.write(f"\n\nTotal Equity: {total_equity:.2f}\n")
    f.write("\nWeighted Beta Calculation (Weight * Beta for each holding):\n")
    for _, row in df.iterrows():
        f.write(f"{row['Symbol']}: {row['Weight']:.4f} * {row['Beta']:.4f} = {row['Weight']*row['Beta']:.4f}\n")
    f.write(f"\nPortfolio Beta: {portfolio_beta:.4f}\n")

# --- Standard deviation based risk (assumes no correlation, i.e., diagonal covariance) ---
# If you want to use real correlations, you need historical price data for all holdings
# Here, we use yfinance to fetch 1-year daily returns for each symbol
returns = []
symbols = df['Symbol'].tolist()
for symbol in symbols:
    try:
        data = yf.Ticker(symbol).history(period='1y')['Close']
        ret = data.pct_change().dropna()
        returns.append(ret)
    except Exception:
        returns.append(pd.Series(dtype=float))

returns_df = pd.concat(returns, axis=1)
returns_df.columns = symbols
cov_matrix = returns_df.cov()
weights = df.set_index('Symbol').loc[symbols, 'Weight'].values
# Portfolio variance: w.T * Cov * w
portfolio_var = np.dot(weights.T, np.dot(cov_matrix, weights))
portfolio_std = np.sqrt(portfolio_var)

with open('portfolio_std.txt', 'w') as f:
    f.write('Portfolio Standard Deviation Calculation Details\n')
    f.write('----------------------------------------------\n')
    f.write('Weights:\n')
    for symbol, weight in zip(symbols, weights):
        f.write(f"{symbol}: {weight:.4f}\n")
    f.write('\nCovariance Matrix:\n')
    f.write(cov_matrix.to_string())
    f.write(f"\n\nPortfolio Variance: {portfolio_var:.8f}\n")
    f.write(f"Portfolio Standard Deviation (annualized): {portfolio_std:.4%}\n")
